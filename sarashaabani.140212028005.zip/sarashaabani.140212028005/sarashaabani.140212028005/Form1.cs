﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sarashaabani._140212028005
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string infix = textBox1.Text;
            string postfix = ConvertInfixToPostfix(infix);
            textBox2.Text = postfix;
        }
        private string ConvertInfixToPostfix(string infix)
        {
            Stack<char> stack = new Stack<char>();
            string postfix = string.Empty;
            for (int i = 0; i < infix.Length; i++)
            {
                char c = infix[i];
                if (Char.IsLetterOrDigit(c))
                {
                    postfix += c;
                }
                else if (c == '(')
                {
                    stack.Push(c);
                }
                else if (c == ')')
                {
                    while (stack.Count > 0 && stack.Peek() != '(')
                    {
                        postfix += stack.Pop();
                    }
                    stack.Pop();
                }

                else
                {
                    while (stack.Count > 0 && Precedence(c) <= Precedence(stack.Peek()))
                    {
                        postfix += stack.Pop();
                    }
                    stack.Push(c);
                }
            }
            while (stack.Count > 0)
            {
                postfix += stack.Pop();
            }
            return postfix;
        }
        private int Precedence(char op)
        {
            switch (op)
            {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                case '^':
                    return 3;
            }
            return -1;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string postfix = textBox3.Text;
            string infix = ConvertPostfixToInfix(postfix);
            textBox4.Text = infix;
        }
        private string ConvertPostfixToInfix(string postfix)
        {
            Stack<string> stack = new Stack<string>();
            for (int i = 0; i < postfix.Length; i++)
            {
                char c = postfix[i];
                if (Char.IsLetterOrDigit(c))
                {
                    stack.Push(c.ToString());
                }
                else
                {
                    string operand2 = stack.Pop();
                    string operand1 = stack.Pop();
                    string expression = "(" + operand1 + c + operand2 + ")";
                    stack.Push(expression);
                }
            }
            return stack.Pop();
        }
        private bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
        }
    }
}
